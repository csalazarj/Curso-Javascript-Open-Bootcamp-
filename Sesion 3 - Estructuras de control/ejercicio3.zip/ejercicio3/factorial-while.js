let i = 1;
let factorial = 1;
while (i <= 10) {
  factorial *= i;
  i++;
}

console.log("factorial", factorial);
